<?php
// Start the session
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "loan_system";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize form inputs
    $phoneNumber = $conn->real_escape_string($_POST['phoneNumber']);
    $password = $_POST['password']; // No need to sanitize this for password_verify

    // Query to check if the user exists
    $sql = "SELECT * FROM users WHERE phone_number = '$phoneNumber'";
    $result = $conn->query($sql);
    
    // Check if user exists
    if ($result->num_rows > 0) {
        $fetch = $result->fetch_assoc();

        // Verify the hashed password
        if (password_verify($password, $fetch['password'])) {
            // Login successful
            $_SESSION['phone_number'] = $phoneNumber; // Storing phone number in session
            $_SESSION['first_name'] = $fetch['first_name'];
            header("Location: dashboard.php"); // Redirect to a dashboard page
            exit();
        } else {
            // Incorrect password
            header("Location: log_in.php?error=Incorrect password or username. Please try again!");
            exit();
        }
    } else {
        // User not found
        header("Location: log_in.php?error=Incorrect password or username. Please try again!");
        exit();
    }
}

$conn->close();
?>
