<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "loan_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize form inputs
    $firstName = $conn->real_escape_string($_POST['firstName']);
    $lastName = $conn->real_escape_string($_POST['lastName']);
    $idNumber = $conn->real_escape_string($_POST['idNumber']);
    $phoneNumber = $conn->real_escape_string($_POST['phoneNumber']);
    $location = $conn->real_escape_string($_POST['location']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = password_hash($conn->real_escape_string($_POST['password']), PASSWORD_DEFAULT); // Hash the password

    // Check if the phone number already exists
    $checkPhoneSql = "SELECT * FROM users WHERE phone_number = '$phoneNumber'";
    $result = $conn->query($checkPhoneSql);

    if ($result->num_rows > 0) {
        echo "The phone number you are trying to register with already exists. Please try another one.";
    } else {
        // Insert data into the database
        $sql = "INSERT INTO users (first_name, last_name, id_number, phone_number, location, email, password)
                VALUES ('$firstName', '$lastName', '$idNumber', '$phoneNumber', '$location', '$email', '$password')";

        if ($conn->query($sql) === TRUE) {
            // Registration successful
            echo "success"; // Return a success string
        } else {
            // Show error message
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

// Close the database connection
$conn->close();
?>
