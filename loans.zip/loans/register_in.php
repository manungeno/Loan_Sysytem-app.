<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            background-color: #f8f9fa;
            font-family: 'Playfair Display', serif;
        }
        .container-fluid {
            height: 100%;
        }
        .image-container {
            height: 100vh;
            overflow: hidden;
        }
        .image-container img {
            height: 100%;
            width: 100%;
            object-fit: cover;
            border-radius: 0;
        }
        .form-container {
            background: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
            max-width: 100%;
            width: 400px;
            height: 90vh;
            margin: auto;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
        }
        .form-container h2 {
            margin-bottom: 20px;
            font-weight: 700;
            font-size: 1.8rem;
            color: #007bff;
            text-align: center;
        }
        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .form-group label {
            font-weight: 600;
        }
        .login-link {
            text-align: center;
            margin-top: 20px;
        }
        .login-link a {
            color: #007bff;
            text-decoration: none;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
        .error-message {
            color: red;
            font-size: 0.9rem;
        }
        .highlight {
            background-color: #ffdddd; /* Light red background for highlighted fields */
        }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <!-- Left Column with Image -->
        <div class="col-lg-6 d-none d-lg-block image-container">
            <img src="register.jpg" alt="Demonstration of Web Functionality">
        </div>
        
        <!-- Right Column with Form -->
        <div class="col-lg-6 d-flex align-items-center justify-content-center">
            <div class="form-container">
                <h2>Register Now</h2>
                <form id="registrationForm" onsubmit="return validateForm()">
                    
                    <!-- First Name -->
                    <div class="form-group">
                        <label for="firstName">First Name</label>
                        <input type="text" class="form-control" id="firstName" name="firstName" placeholder="Enter First Name" required>
                        <div class="error-message" id="firstNameError"></div>
                    </div>
                    
                    <!-- Last Name -->
                    <div class="form-group">
                        <label for="lastName">Last Name</label>
                        <input type="text" class="form-control" id="lastName" name="lastName" placeholder="Enter Last Name" required>
                        <div class="error-message" id="lastNameError"></div>
                    </div>
                    
                    <!-- ID Number -->
                    <div class="form-group">
                        <label for="idNumber">ID Number</label>
                        <input type="number" class="form-control" id="idNumber" name="idNumber" placeholder="Enter ID Number" required>
                        <div class="error-message" id="idNumberError"></div>
                    </div>
                    
                    <!-- Phone Number -->
                    <div class="form-group">
                        <label for="phoneNumber">Phone Number</label>
                        <input type="text" class="form-control" id="phoneNumber" name="phoneNumber" placeholder="Enter 10-digit Phone Number" required>
                        <div class="error-message" id="phoneNumberError"></div>
                    </div>

                    <!-- Location (Counties in Kenya) -->
                    <div class="form-group">
                        <label for="location">Location (County)</label>
                        <select class="form-control" id="location" name="location" required>
                            <option value="">Select County</option>
                        </select>
                    </div>
                    
                    <!-- Email -->
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email" required>
                        <div class="error-message" id="emailError"></div>
                    </div>
                    
                    <!-- Password -->
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password" required>
                        <div class="error-message" id="passwordError"></div>
                    </div>
                    
                    <!-- Confirm Password -->
                    <div class="form-group">
                        <label for="confirmPassword">Confirm Password</label>
                        <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" placeholder="Confirm Password" required>
                        <div class="error-message" id="confirmPasswordError"></div>
                    </div>
                    
                    <!-- Submit Button -->
                    <button type="submit" class="btn btn-primary btn-block">Register</button>
                </form>
                
                <!-- Already Have an Account Link -->
                <div class="login-link">
                    <p>Already have an account? <a href="log_in.php">Log in here</a></p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Array of Kenyan counties
    const counties = [
        "Bomet", "Bungoma", "Busia", "Elgeyo-Marakwet", "Embu", "Garissa", 
        "Homa Bay", "Isiolo", "Kakamega", "Kericho", "Kiambu", "Kilifi", 
        "Kirinyaga", "Kisii", "Kisumu", "Laikipia", "Lamu", "Machakos", 
        "Makueni", "Mandera", "Marsabit", "Meru", "Migori", "Nakuru", 
        "Nandi", "Narok", "Nyamira", "Nyandarua", "Nyeri", "Samburu", 
        "Siaya", "Taita Taveta", "Tana River", "Tharaka Nithi", "Trans Nzoia", 
        "Uasin Gishu", "Vihiga", "Wajir", "West Pokot", "Nairobi (City)", 
        "Mombasa"
    ];

    // Populate the dropdown with counties
    const locationDropdown = document.getElementById("location");
    counties.forEach(county => {
        const option = document.createElement("option");
        option.value = county;
        option.textContent = county;
        locationDropdown.appendChild(option);
    });

    function validateForm() {
    // Clear previous error messages and highlights
    document.querySelectorAll(".error-message").forEach(el => el.textContent = "");
    document.querySelectorAll(".form-control").forEach(el => el.classList.remove("highlight"));

    // Get values from the form
    const firstName = document.getElementById("firstName").value.trim();
    const lastName = document.getElementById("lastName").value.trim();
    const idNumber = document.getElementById("idNumber").value.trim();
    const phoneNumber = document.getElementById("phoneNumber").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();
    const confirmPassword = document.getElementById("confirmPassword").value.trim();

    let isValid = true;

    // Validate first name
    if (!firstName) {
        document.getElementById("firstNameError").textContent = "First name is required.";
        document.getElementById("firstName").classList.add("highlight");
        isValid = false;
    }

    // Validate last name
    if (!lastName) {
        document.getElementById("lastNameError").textContent = "Last name is required.";
        document.getElementById("lastName").classList.add("highlight");
        isValid = false;
    }

    // Validate ID Number
    if (!idNumber) {
        document.getElementById("idNumberError").textContent = "ID Number is required.";
        document.getElementById("idNumber").classList.add("highlight");
        isValid = false;
    }

    // Validate phone number (starts with '07' and has 10 digits)
    if (!/^07\d{8}$/.test(phoneNumber)) {
        document.getElementById("phoneNumberError").textContent = "Phone number must start with '07' and be 10 digits.";
        document.getElementById("phoneNumber").classList.add("highlight");
        isValid = false;
    }

    // Validate email
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // Basic email format regex
    if (!emailPattern.test(email)) {
        document.getElementById("emailError").textContent = "Please enter a valid email address.";
        document.getElementById("email").classList.add("highlight");
        isValid = false;
    }

      // Validate password (at least 4 characters)
      if (password.length < 4) {
        document.getElementById("passwordError").textContent = "Password must be at least 4 characters.";
        document.getElementById("password").classList.add("highlight");
        isValid = false;
    }

    // Validate password confirmation
    if (password !== confirmPassword) {
        document.getElementById("passwordError").textContent = "Passwords do not match.";
        document.getElementById("confirmPasswordError").textContent = "Passwords do not match.";
        document.getElementById("password").classList.add("highlight");
        document.getElementById("confirmPassword").classList.add("highlight");
        isValid = false;
    }

    // If the form is valid, send data to the server
    if (isValid) {
        const formData = new FormData();
        formData.append('firstName', firstName);
        formData.append('lastName', lastName);
        formData.append('idNumber', idNumber);
        formData.append('phoneNumber', phoneNumber);
        formData.append('location', document.getElementById("location").value.trim()); // Assuming you have a location dropdown
        formData.append('email', email);
        formData.append('password', password);

        fetch('http://localhost/loans/register.php', {
    method: 'POST',
    body: formData
})
.then(response => response.text())
.then(data => {
    console.log("Response from server:", data); // Log the response for debugging
    // Handle the server response
    if (data.trim() === "success") { // Check if the response is exactly "success"
        alert("Registration successful!");
        window.location.href = "log_in.php"; // Redirect to the login page
    } else {
        // Show server error message
        alert(data); // Display the error message returned from the server
    }
})
.catch(error => {
    console.error('Error:', error); // Log any fetch errors
    alert("An error occurred during registration. Please try again.");
});

        return false; // Prevent the form from submitting the traditional way
    }

    return false; // Prevent form submission if validation fails
}


    // Clear form on successful submission
    window.onload = function() {
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('success')) {
            document.getElementById("registrationForm").reset(); // Clear the form fields
            alert("Registration successful!"); // Optional: Show a success message
        }
    };
</script>

</body>
</html>
