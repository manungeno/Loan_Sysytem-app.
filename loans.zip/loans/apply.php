<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "loan_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the data from the request
    $fullName = isset($_POST['fullName']) ? $conn->real_escape_string($_POST['fullName']) : '';
    $phoneNumber = isset($_POST['phoneNumber']) ? $conn->real_escape_string($_POST['phoneNumber']) : '';
    $loanAmount = isset($_POST['loanAmount']) ? $conn->real_escape_string($_POST['loanAmount']) : '';
    $loanPurpose = isset($_POST['loanPurpose']) ? $conn->real_escape_string($_POST['loanPurpose']) : '';

    // Validate input data
    if (empty($fullName) || empty($phoneNumber) || empty($loanAmount) || empty($loanPurpose)) {
        echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
        exit;
    }

    // Calculate processing fee based on loan amount
    $processingFee = 0;
    if ($loanAmount >= 5000 && $loanAmount <= 7000) {
        $processingFee = 100;
    } elseif ($loanAmount >= 7001 && $loanAmount <= 9000) {
        $processingFee = 150;
    } elseif ($loanAmount >= 9001 && $loanAmount <= 11000) {
        $processingFee = 200;
    } elseif ($loanAmount >= 11001 && $loanAmount <= 50000) {
        $processingFee = 500;
    }

    // Insert data into the loan_applications table
    $sql = "INSERT INTO loan_applications (full_name, phone_number, loan_amount, processing_fee, loan_purpose) VALUES ('$fullName', '$phoneNumber', '$loanAmount', '$processingFee','$loanPurpose')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['status' => 'success', 'message' => 'Application submitted successfully!']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error: ' . $conn->error]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}

// Close connection
$conn->close();
?>
