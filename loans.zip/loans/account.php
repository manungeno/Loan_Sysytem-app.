<?php
// account.php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "loan_system";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['phone_number'])) {
    header("Location: login.php");
    exit();
}

// Retrieve user information
$phoneNumber = $_SESSION['phone_number'];

// Query to get user details
$sql = "SELECT * FROM users WHERE phone_number = '$phoneNumber'";
$userResult = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($userResult);

$phone = $user["phone_number"];

// Query to get loan transactions for the user
$transactionsSql = "SELECT * FROM loan_applications WHERE phone_number = '$phone'";
$transactionsResult = mysqli_query($conn, $transactionsSql);

// Check if there are any transactions
if ($transactionsResult && mysqli_num_rows($transactionsResult) > 0) {
    while ($loan = mysqli_fetch_assoc($transactionsResult)) {
        // Check if the loan array and its keys are set and not null
        $loanAmount = isset($loan["loan_amount"]) ? number_format($loan["loan_amount"], 0, '.', ',') : "N/A";
        $processingFee = isset($loan["processing_fee"]) ? $loan["processing_fee"] : 0;
        $totalAmount = isset($loan["loan_amount"]) ? number_format($loan["loan_amount"] + $processingFee, 0, '.', ',') : "N/A";
        $submittedAt = isset($loan["submitted_at"]) ? date("d-m-Y", strtotime($loan["submitted_at"])) : "N/A";
        ?>
        <tr>
            <td><?php echo $loanAmount; ?></td>
            <td><?php echo $totalAmount; ?></td>
            <td><?php echo $submittedAt; ?></td>
        </tr>
        <?php
    }
} else {
    echo "<tr><td colspan='3'>No transactions found.</td></tr>";
}

$conn->close();
?>
