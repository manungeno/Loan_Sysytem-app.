<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Playfair Display', serif;
        }
        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 70vh;
        }
        .login-form {
            background: white;
            padding: 20px;
            border-radius: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 400px;
        }
        .form-header {
            text-align: center;
            margin-bottom: 20px;
        }
        /* Change title color */
        .form-header h3 {
            color: #007bff; /* Bootstrap primary color */
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="login-container">
    <form class="login-form" action="login.php" method="POST">
        <?php 
        if(isset($_GET["error"])){
            $error = $_GET["error"];?>    
            <div class="alert alert-danger">
                <?php echo $error?>
            </div>
        <?php 
        }
        ?>
        <div class="form-header">
            <h3>Login</h3>
        </div>
        <div class="form-group">
            <label for="phoneNumber">Phone Number</label>
            <input type="text" class="form-control" id="phoneNumber" name="phoneNumber" placeholder="Enter your phone number" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block">Login</button>
        <div class="text-center mt-3">
            <p>Don't have an account? <a href="register_in.php">Register here</a></p>
        </div>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
