<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Form - Pesa Chap Chap</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            background-color: #f1f5f9;
            font-family: 'Playfair Display', serif;
        }
        .container {
            max-width: 600px;
            margin: auto;
            padding-top: 20px;
        }
        .header {
            background-color: #007bff;
            color: white;
            padding: 15px;
            text-align: center;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .form-section {
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 25px 30px;
            background-color: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        .form-group label {
            font-weight: bold;
            color: #555;
            text-align: left;
            display: block;
        }
        .form-control {
            padding: 10px;
            border-radius: 5px;
            margin-top: 5px;
            margin-bottom: 15px;
        }
        .btn {
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }
        .btn-proceed {
            background-color: #007bff;
            color: white;
            transition: 0.3s;
            margin-top: 20px;
        }
        .btn-proceed:hover {
            background-color: #0056b3;
        }
        .preview-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .preview-content {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            max-width: 600px;
            width: 100%;
            text-align: center;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        }
        .preview-header {
            background-color: #28a745;
            color: white;
            padding: 10px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            margin-bottom: 15px;
        }
        .btn-submit {
            background-color: #007bff;
            color: white;
            margin: 10px 0;
            transition: 0.3s;
            width: calc(100% - 20px);
        }
        .btn-secondary {
            margin: 10px 0;
            width: calc(100% - 20px);
        }
        /* Loading Animation */
        .loading {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            z-index: 999;
        }
        .spinner-border {
            width: 3rem;
            height: 3rem;
        }
    </style>
</head>
<body>

<div class="container">
    <!-- Application Form Header -->
    <header class="header">
        <h1>Apply Now</h1>
    </header>

    <!-- Application Form Section -->
    <div class="form-section">
        <form id="applicationForm">
            <div class="form-group">
                <label for="fullName" class="text-left">Full Name</label>
                <input type="text" class="form-control" id="fullName" placeholder="Enter your name as indicated in your ID" required>
            </div>
            <div class="form-group">
                <label for="phoneNumber" class="text-left">Phone Number</label>
                <input type="tel" class="form-control" id="phoneNumber" placeholder="Enter your phone number to receive this loan" required>
            </div>
            <div class="form-group">
                <label for="loanAmount" class="text-left">Loan Amount (KSH)</label>
                <input type="number" class="form-control" id="loanAmount" placeholder="Enter loan amount you would like to receive" required>
            </div>
            <div class="form-group">
                <label for="loanPurpose" class="text-left">Loan Purpose</label>
                <textarea class="form-control" id="loanPurpose" rows="3" placeholder="Describe the purpose of the loan" required></textarea>
            </div>
            <button type="button" class="btn btn-proceed" id="proceedButton">Proceed</button>
        </form>
    </div>
</div>

<!-- Preview Modal -->
<div class="preview-modal" id="previewModal">
    <div class="preview-content">
        <div class="preview-header">
            <h3>Confirm Your Details and Submit</h3>
        </div>
        <table class="table table-bordered table-striped colorful">
            <tbody>
                <tr>
                    <td><strong>Full Name:</strong></td>
                    <td id="previewFullName"></td>
                </tr>
                <tr>
                    <td><strong>Phone Number:</strong></td>
                    <td id="previewPhoneNumber"></td>
                </tr>
                <tr>
                    <td><strong>Loan Amount:</strong></td>
                    <td>KSH <span id="previewLoanAmount"></span></td>
                </tr>
                <tr>
                    <td><strong>Processing Fee:</strong></td>
                    <td id="previewProcessingFee"></td>
                </tr>
                <tr>
                    <td><strong>Loan Purpose:</strong></td>
                    <td id="previewLoanPurpose"></td>
                </tr>
            </tbody>
        </table>
        <button type="button" class="btn btn-submit" id="submitButton">Submit Application</button>
        <button type="button" class="btn btn-secondary" id="backButton">Back to Form</button>
    </div>
</div>

<!-- Loading Animation -->
<div class="loading" id="loading">
    <div class="spinner-border" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>

<script>
    let applicationSubmitted = false;

    function calculateProcessingFee(amount) {
        if (amount >= 5000 && amount <= 7000) return 100;
        else if (amount >= 7001 && amount <= 9000) return 150;
        else if (amount >= 9001 && amount <= 11000) return 200;
        else if (amount >= 11001 && amount <= 50000) return 500;
        else return 0;
    }

    document.getElementById('proceedButton').addEventListener('click', function() {
        const fullName = document.getElementById('fullName').value.trim();
        const phoneNumber = document.getElementById('phoneNumber').value.trim();
        const loanAmount = parseInt(document.getElementById('loanAmount').value.trim());
        const loanPurpose = document.getElementById('loanPurpose').value.trim();

        if (isNaN(loanAmount) || loanAmount < 5000) {
            alert("You cannot apply for less than 5000 KSH.");
            return;
        }

        if (fullName && phoneNumber && loanAmount && loanPurpose) {
            const processingFee = calculateProcessingFee(loanAmount);

            document.getElementById('previewFullName').innerText = fullName;
            document.getElementById('previewPhoneNumber').innerText = phoneNumber;
            document.getElementById('previewLoanAmount').innerText = loanAmount;
            document.getElementById('previewProcessingFee').innerText = `KSH ${processingFee}`;
            document.getElementById('previewLoanPurpose').innerText = loanPurpose;
            

            document.getElementById('previewModal').style.display = 'flex';
        } else {
            alert('Please fill in all fields before proceeding.');
        }
    });

    document.getElementById('backButton').addEventListener('click', function() {
        document.getElementById('previewModal').style.display = 'none';
    });

    document.getElementById('submitButton').addEventListener('click', function() {
    // Show loading animation
    document.getElementById('loading').style.display = 'flex';

    // Get form data
    const fullName = document.getElementById('fullName').value.trim();
    const phoneNumber = document.getElementById('phoneNumber').value.trim();
    const loanAmount = parseInt(document.getElementById('loanAmount').value.trim());
    const processingFee = calculateProcessingFee(loanAmount);
    const loanPurpose = document.getElementById('loanPurpose').value.trim();
   

    // Prepare data to send
    const formData = new FormData();
    formData.append('fullName', fullName);
    formData.append('phoneNumber', phoneNumber);
    formData.append('loanAmount', loanAmount);
    formData.append('processingFee', processingFee);
    formData.append('loanPurpose', loanPurpose);
   

    // Send data using AJAX
    fetch('apply.php', { 
        method: 'POST',
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        // Hide loading animation
        document.getElementById('loading').style.display = 'none';

        if (data.status === 'success') {
            alert(data.message); // Show success message
            // Redirect to the dashboard page
            window.location.href = 'dashboard.php';
        } else {
            alert('Error: ' + data.message); // Show error message
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while submitting your application.');
        document.getElementById('loading').style.display = 'none'; // Hide loading animation in case of error
    });
});

</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
