<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesa Chap Chap</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            background-color: #f8f9fa;
            font-family: 'Playfair Display', serif;
        }
        .hero {
            background-color: #007bff;
            color: white;
            padding: 20px 0;
            text-align: center;
            border-radius: 20px 20px 20px 20px; /* Rounded bottom corners */
        }
        .features {
            padding: 20px;
        }
        .feature-item {
            margin: 20px 0;
            text-align: center; /* Center text and images */
        }
        .feature-item img {
            max-width: 100%; /* Responsive image */
            height: auto;
            border-radius: 8px; /* Optional: to round the corners of the images */
        }
        footer {
            background-color: #343a40;
            color: white;
            padding: 10px 0;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container-fluid">
    <!-- Hero Section -->
    <header class="hero">
        <h1>Welcome to Pesa Chap Chap Loans</h1>
        <p>Your Trusted Financial Assistant</p>
        <a href="register_in.php" class="btn btn-light btn-lg">Register Now</a>
        <a href="log_in.php" class="btn btn-light btn-lg">Login</a>
    </header>

    <!-- Features Section -->
    <div class="features">
        <h2 class="text-center">Features</h2>
        <div class="row">
            <div class="col-md-4 feature-item">
                <h3>Easy Registration</h3>
                <img src="easy.jpg" alt="Easy Registration">
                <p>Sign up in minutes and start managing your loans today.</p>
            </div>
            <div class="col-md-4 feature-item">
                <h3>Manage Loans</h3>
                <img src="manage.jpg" alt="Manage Loans">
                <p>Track your loan status and manage repayments effortlessly.</p>
            </div>
            <div class="col-md-4 feature-item">
                <h3>Secure Transactions</h3>
                <img src="secure.jpg" alt="Secure Transactions">
                <p>Your data and transactions are protected with the highest security standards.</p>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
