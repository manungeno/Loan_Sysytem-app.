<?php
// account.php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "loan_system";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['phone_number'])) {
    header("Location: login.php");
    exit();
}