<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<header class="header">
    <h1>
        <i class="fas fa-dollar-sign"></i> Esteemed client, <?php echo $_SESSION['first_name']; ?>
    </h1>
    <p>Enjoy flexible repayment options with our loans—borrow now and repay at your convenience.</p>
    <button class="btn btn-danger" onclick="confirmLogout()">Logout</button>
</header>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Pesa Chap Chap</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">

    <style>
        body, html {
            height: 100%;
            margin: 0;
            background-color: #f1f5f9;
            font-family: 'Roboto', sans-serif; /* Use Google Font */
            display: flex;
            flex-direction: column;
        }
        .header {
            background-color: #007bff;
            color: white;
            padding: 10px;
            font-family: 'Roboto', sans-serif;
            text-align: center;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .header h1 {
            font-family: 'Playfair Display', serif; /* Header font */
        }
        .btn-apply {
            background-color: #007bff;
            color: white;
            font-weight: bold;
            transition: 0.3s;
        }
        .btn-apply:hover {
            background-color: red;
        }
        .btn-account {
            background-color: #17a2b8;
            color: white;
            font-weight: bold;
            transition: 0.3s;
        }
        .btn-account:hover {
            background-color: #138496;
        }
        footer {
            padding: 20px 0;
            background-color: #343a40; /* Darker footer color */
            color: white;
            text-align: center;
            margin-top: auto; /* Push the footer to the bottom */
        }
        .footer-icons a {
            color: white;
            margin: 0 15px;
            font-size: 24px;
            transition: color 0.3s;
        }
        .footer-icons a:hover {
            color: #ffc107;
        }
        .stats-container {
            margin-top: 20px;
            font-family: 'Playfair Display', serif;
        }
        .stat-card {
            border-radius: 8px;
            padding: 20px;
            color: white;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .fa-3x {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="row">
        <marquee behavior="" direction="right-left"><strong>Remember, No CRB...</strong></marquee>
        
        <!-- Left Box: Loan Information -->
        <div class="col-md-4 mb-4">
            <div class="card text-white bg-success">
                <div class="card-body">
                    <h3 class="card-title">About Our Loans</h3>
                    <p class="card-text">Our loans are here to help you manage your money easily. You can apply quickly without hassle. <br>Choose any amount you need and pay it back when it works for you. We want to help you through financial challenges without adding any pressure.</p>
                </div>
            </div>
        </div>

        <!-- Center Box: Loan Limit Eligibility -->
        <div class="col-md-4 mb-4">
            <div class="card text-white bg-warning text-center">
                <div class="card-body">
                    <h3 class="card-title">Your Loan Limit</h3>
                    <p class="card-text"><strong>Eligible Limit:</strong> KSH 5,000 - 50,000</p>
                    <div class="d-flex justify-content-between mt-4">
                        <a href="apply_in.php" class="btn btn-apply">Apply Now</a>
                        <a href="account_view.php" class="btn btn-account">View Account</a>
                    </div>
                    <p>Apply for a loan by clicking the "Apply Now". View status account by clicking the "View Account".</p>
                </div>
            </div>
        </div>

        <!-- Right Box: Loan Reward Information -->
        <div class="col-md-4 mb-4">
            <div class="card text-white bg-info">
                <div class="card-body">
                    <h3 class="card-title">Timely Repayment Rewards</h3>
                    <p class="card-text">When you repay your loan on time, you’ll be eligible for a higher loan limit on future loans. Stay committed, and grow your borrowing capacity!<br><strong>Stay tuned! <br>Stay safe </strong></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistics Container -->
    <div class="container stats-container">
        <h2 class="text-center mb-4"><strong>Standing Loan Borrowers Statistics</strong></h2>
        <div class="row">
            <div class="col-md-3 mb-4">
                <div class="stat-card bg-success">
                    <i class="fas fa-users fa-3x"></i>
                    <h3>Borrowed Loans</h3>
                    <p>1,200,018 People</p>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="stat-card bg-warning">
                    <i class="fas fa-check-circle fa-3x"></i>
                    <h3>Repaid Loans</h3>
                    <p>800,547 People</p>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="stat-card bg-info">
                    <i class="fas fa-trophy fa-3x"></i>
                    <h3>Rewarded</h3>
                    <p>60,083 People</p>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="stat-card bg-danger">
                    <i class="fas fa-times-circle fa-3x"></i>
                    <h3>Unpaid Loans</h3>
                    <p>399,471 People</p>
                </div>
            </div>
        </div>
    </div>

</div>

<footer>
    <div class="footer-icons">
        <a href="mailto:your_email@example.com" title="Email">
            <i class="fas fa-envelope"></i> pesachapchap@gmail.com
        </a>
        <a href="https://wa.me/your_number" title="WhatsApp">
            <i class="fab fa-whatsapp"></i> +254721436587
        </a>
        <a href="https://instagram.com/your_profile" title="Instagram">
            <i class="fab fa-instagram"></i> @chappesachap
        </a>
        <a href="tel:your_phone_number" title="Call">
            <i class="fas fa-phone"></i> 0708967452
        </a>
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    function confirmLogout() {
        if (confirm("Are you sure you want to log out?")) {
            window.location.href = "logout.php"; // Redirect to logout.php
        }
    }
</script>
</body>
</html>
