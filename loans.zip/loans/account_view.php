<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Overview</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        /* Center the entire page content */
        body, html {
            margin: 0;
            background-color: #f1f5f9;
        }

        .account-container {
            display: flex;
            max-width: 1200px;
            width: 100%;
            margin: auto;
            padding: 20px;
        }

        .info-container {
            flex: 1;
            margin-right: 20px;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        .balance-container {
            max-width: 600px;
            width: 100%;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .balance-box {
            padding: 20px;
            background-color: #e2f0ff;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .transaction-table {
            margin-top: 20px;
        }

        /* Styling for icons */
        .user-icon {
            margin-right: 10px;
            color: #007bff;
        }

        .withdraw-btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        .withdraw-btn:hover {
            background-color: #0056b3;
        }

        /* Responsive styling */
        @media (max-width: 768px) {
            .account-container {
                flex-direction: column;
                padding: 15px;
            }

            .info-container {
                margin-right: 0;
                margin-bottom: 20px;
            }

            .balance-container {
                margin-bottom: 20px;
            }

            h2 {
                font-size: 1.5rem;
            }

            .balance-box, .transaction-table {
                font-size: 0.9rem;
            }

            .withdraw-btn {
                width: 100%;
                padding: 10px;
            }
        }
    </style>
</head>
<body>
<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "loan_system";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['phone_number'])) {
    header("Location: login.php");
    exit();
}

// Retrieve user information
$phoneNumber = $_SESSION['phone_number'];

// Query to get user details
$sql = "SELECT * FROM users WHERE phone_number = '$phoneNumber'";
$userResult = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($userResult);
$phone = $user["phone_number"];

// Query to get loan transactions for the user
$transactionsSql = "SELECT * FROM loan_applications WHERE phone_number = '$phone'";
$transactionsResult = mysqli_query($conn, $transactionsSql);
$loan = mysqli_fetch_assoc($transactionsResult); 

// Check if loan data exists
$accountBalance = ($loan) ? number_format($loan["loan_amount"] + $loan["processing_fee"], 2, '.', ',') . ' Shillings' : "0.00 Shillings";
?>

<div class="container account-container">
    <div class="info-container">
        <h4>  <strong>----->ALERT-----></strong></h4>
        <p>Please be aware that before making your withdrawal, you need to cover the processing fee. Remember the amount you borrowed? The balance in your account currently exceeds that amount, indicating that the processing fee has already been reimbursed to you.</p> <hr>
        <p>Tafadhali fahamu kwamba kabla ya kufanya uondoaji wako, unahitaji kulipia ada ya usindikaji. Kumbuka kiasi ulichokopa? Salio katika akaunti yako kwa sasa kinazidi kiasi hicho, ikionyesha kwamba ada ya usindikaji tayari imerejeshwa kwako.</p><hr>
        <p>Just click on <strong>withdraw,</strong> and after a few seconds, you will see a prompt to confirm your processing fee by entering your Mpesa pin. Within 2 minutes, you will receive your loans from <strong>Pesa Chap Chap</strong>.</p>
    </div>

    <div class="balance-container">
        <h2><i class="fas fa-user-circle user-icon"></i><span id="user-name"><?php echo $user["first_name"] . " " . $user["last_name"]; ?></span></h2>
        
        <div class="balance-box">
            <h4>Account Balance</h4>
            <p><strong id="account-balance"><?php echo $accountBalance; ?></strong></p>
            <!-- Withdraw button with dollar sign -->
            <button class="withdraw-btn">
                <i class="fas fa-dollar-sign"></i> <!-- Dollar sign icon -->
                <i class="fas fa-money-check-alt"></i> Withdraw
            </button>
        </div>

        <h4>Your Loan History, Keep tracking your progress</h4>
        <table class="table table-striped transaction-table">
            <thead>
                <tr>   
                    <th>Amount Borrowed</th>
                    <th>Withdrawal Amount</th>
                    <th>Date Borrowed</th>
                </tr>
            </thead>
            <tbody id="transaction-history">
                <?php
                if ($loan) {
                    echo "<tr>
                            <td>" . number_format($loan["loan_amount"], 0, '.', ',') . "</td>
                            <td>" . number_format($loan["loan_amount"] + $loan["processing_fee"], 0, '.', ',') . "</td>
                            <td>" . date("d-m-Y", strtotime($loan["submitted_at"])) . "</td> 
                          </tr>";
                } else {
                    echo "<tr><td colspan='3' class='text-center'>Loan not yet borrowed.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
